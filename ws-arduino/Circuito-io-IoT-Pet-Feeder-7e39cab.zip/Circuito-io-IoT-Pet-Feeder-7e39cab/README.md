# iot-pet-feeder

Link to the full tutorial on our blog >> https://www.circuito.io/blog/automatic-pet-feeder/
Notes: 
1. After downloading the code, make sure that the pin settings match those you received from circuito.io test code.
2. Add your Wifi name and password in the designated place in the code
3. Add the automatically generated Tokens to the code
4. Open Freeboard and click "import" as explained in the tutorial.
For more help, pm us on facebook - https://www.facebook.com/circuito.io/
