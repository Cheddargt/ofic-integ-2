#include "PiezoSpeaker.h"

PiezoSpeaker::PiezoSpeaker(int pin) : Speaker(pin){
  
}
